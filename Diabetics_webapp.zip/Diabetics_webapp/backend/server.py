from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import numpy as np
from fastapi.middleware.cors import CORSMiddleware

# Load models
outcome_model = joblib.load("diabetes_outcome_model.pkl")
severity_model = joblib.load("diabetes_severity_model.pkl")
scaler = joblib.load("diabetes_scaler.pkl")

app = FastAPI()

# Allow frontend (React) to communicate with backend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class InputData(BaseModel):
    Pregnancies: float
    Glucose: float
    BloodPressure: float
    SkinThickness: float
    Insulin: float
    BMI: float
    DiabetesPedigreeFunction: float
    Age: float

@app.post("/predict")
def predict(data: InputData):

    sample = np.array([[  
        data.Pregnancies,
        data.Glucose,
        data.BloodPressure,
        data.SkinThickness,
        data.Insulin,
        data.BMI,
        data.DiabetesPedigreeFunction,
        data.Age
    ]])

    sample_scaled = scaler.transform(sample)

    # Stage 1 Prediction
    diabetes_pred = int(outcome_model.predict(sample_scaled)[0])
    diabetes_prob = float(outcome_model.predict_proba(sample_scaled)[0][1])

    # No diabetes → severity = 0
    if diabetes_pred == 0:
        return {
            "diabetes": diabetes_pred,
            "probability": diabetes_prob,
            "severity": 0,
            "severity_text": "No diabetes – no severity level"
        }

    # Stage 2 Prediction (0,1,2 severity classes)
    severity_pred = int(severity_model.predict(sample_scaled)[0])
    
    # Correct mapping (after label shifting)
    severity_text = {
        0: "Low severity diabetes",
        1: "Medium severity diabetes",
        2: "High severity diabetes"
    }.get(severity_pred, "Unknown severity")

    return {
        "diabetes": diabetes_pred,
        "probability": diabetes_prob,
        "severity": severity_pred,
        "severity_text": severity_text
    }
