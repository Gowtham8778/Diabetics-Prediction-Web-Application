import { useState } from "react";

function App() {
  const [formData, setFormData] = useState({
    Pregnancies: "",
    Glucose: "",
    BloodPressure: "",
    SkinThickness: "",
    Insulin: "",
    BMI: "",
    DiabetesPedigreeFunction: "",
    Age: "",
  });

  const [result, setResult] = useState(null);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async () => {
    const res = await fetch("http://127.0.0.1:8000/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData),
    });

    const data = await res.json();
    setResult(data);
  };

  return (
    <div style={{ width: "400px", margin: "auto", padding: "20px" }}>
      <h2>Diabetes Prediction</h2>

      {Object.keys(formData).map((key) => (
        <div key={key}>
          <label>{key}</label>
          <input
            type="number"
            name={key}
            value={formData[key]}
            onChange={handleChange}
            style={{ width: "100%", marginBottom: "10px", padding: "5px" }}
          />
        </div>
      ))}

      <button 
        onClick={handleSubmit}
        style={{ padding: "10px", marginTop: "10px", width: "100%" }}
      >
        Predict
      </button>

      {result && (
        <div style={{ marginTop: "20px" }}>
          <h3>Results:</h3>
          <p><strong>Diabetes:</strong> {result.diabetes === 1 ? "Yes" : "No"}</p>
          <p><strong>Probability:</strong> {result.probability.toFixed(2)}</p>
          <p><strong>Severity:</strong> {result.severity_text}</p>
        </div>
      )}
    </div>
  );
}

export default App;
